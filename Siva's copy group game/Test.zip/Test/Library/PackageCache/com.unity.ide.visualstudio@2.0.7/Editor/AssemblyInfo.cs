﻿using System.Runtime.CompilerServices;

[assembly:InternalsVisibleTo("Unity.VisualStudio.EditorTests")]
[assembly: InternalsVisibleTo("DynamicProxyGenAssembly2")]
